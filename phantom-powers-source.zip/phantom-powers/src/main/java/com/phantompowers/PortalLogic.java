package com.phantompowers;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class PortalLogic {
	public static final RegistryKey<World> GHOST_ZONE = RegistryKey.of(RegistryKeys.WORLD, PhantomMod.id("ghost_zone"));

	private static final int MAX_INTERIOR = 64;
	private static final int IRON_NEEDED = 5;
	private static final int TRAVEL_COOLDOWN = 60;

	private static final List<Runnable> NEXT_TICK = new ArrayList<>();
	private static final Map<UUID, BlockPos> TRAVEL = new LinkedHashMap<>();
	private static final Map<UUID, Integer> LAST_TRAVEL = new HashMap<>();

	private PortalLogic() {}

	public static void later(Runnable r) {
		NEXT_TICK.add(r);
	}

	public static void tick(MinecraftServer server) {
		if (!NEXT_TICK.isEmpty()) {
			List<Runnable> run = new ArrayList<>(NEXT_TICK);
			NEXT_TICK.clear();
			run.forEach(Runnable::run);
		}
		if (!TRAVEL.isEmpty()) {
			Map<UUID, BlockPos> todo = new LinkedHashMap<>(TRAVEL);
			TRAVEL.clear();
			todo.forEach((id, pos) -> {
				ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
				if (p != null && p.isAlive()) travel(p, pos);
			});
		}
	}

	// ------------------------------------------------------------ activation

	public static void onButtonPressed(ServerPlayerEntity p, ServerWorld w, BlockPos buttonPos) {
		BlockPos pos = buttonPos.toImmutable();
		later(() -> tryActivate(p, w, pos));
	}

	private record Frame(Direction.Axis axis, Set<BlockPos> interior) {}

	/** Looks for a closed frame of iron blocks + black concrete around the button, in either direction. */
	private static Frame findFrame(ServerWorld w, BlockPos start) {
		for (Direction.Axis axis : new Direction.Axis[]{Direction.Axis.X, Direction.Axis.Z}) {
			Frame f = scan(w, start, axis);
			if (f != null) return f;
		}
		return null;
	}

	private static Frame scan(ServerWorld w, BlockPos start, Direction.Axis axis) {
		Direction side = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
		Direction[] dirs = {side, side.getOpposite(), Direction.UP, Direction.DOWN};
		Set<BlockPos> interior = new HashSet<>();
		Set<BlockPos> frame = new HashSet<>();
		ArrayDeque<BlockPos> queue = new ArrayDeque<>();
		interior.add(start);
		queue.add(start);
		while (!queue.isEmpty()) {
			BlockPos cur = queue.poll();
			for (Direction d : dirs) {
				BlockPos n = cur.offset(d);
				if (interior.contains(n) || frame.contains(n)) continue;
				BlockState s = w.getBlockState(n);
				if (isFrame(s)) {
					frame.add(n);
				} else if (isOpening(s)) {
					interior.add(n);
					if (interior.size() > MAX_INTERIOR) return null;
					queue.add(n);
				} else {
					return null; // something else is in the way: not a closed frame
				}
			}
		}
		int iron = 0;
		for (BlockPos f : frame) if (w.getBlockState(f).isOf(Blocks.IRON_BLOCK)) iron++;
		if (iron < IRON_NEEDED) return null;
		return new Frame(axis, interior);
	}

	private static boolean isFrame(BlockState s) {
		return s.isOf(Blocks.IRON_BLOCK) || s.isOf(Blocks.BLACK_CONCRETE);
	}

	private static boolean isOpening(BlockState s) {
		return s.isAir() || s.getBlock() instanceof ButtonBlock;
	}

	private static void tryActivate(ServerPlayerEntity p, ServerWorld w, BlockPos buttonPos) {
		if (!(w.getBlockState(buttonPos).getBlock() instanceof ButtonBlock)) return;
		Frame f = findFrame(w, buttonPos);
		if (f == null) return;

		// Is the player standing inside the portal opening?
		boolean inside = false;
		for (BlockPos ip : f.interior()) {
			if (p.getWorld() == w && p.getBlockPos().getSquaredDistance(ip) <= 2.5) {
				inside = true;
				break;
			}
		}

		// Light it up
		BlockState portal = ModBlocks.GHOST_PORTAL.getDefaultState().with(GhostPortalBlock.AXIS, f.axis());
		for (BlockPos ip : f.interior()) w.setBlockState(ip, portal, Block.NOTIFY_ALL);

		Vec3d center = centerOf(f);
		Vec3d front = frontOf(w, f);
		LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
		if (bolt != null) {
			bolt.setCosmetic(true);
			bolt.refreshPositionAfterTeleport(center);
			w.spawnEntity(bolt);
		}
		w.playSound(null, center.x, center.y, center.z, SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.BLOCKS, 2.0f, 0.6f);
		w.playSound(null, center.x, center.y, center.z, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 1.0f, 1.4f);
		w.spawnParticles(GhostPowers.GREEN, center.x, center.y, center.z, 120, 0.8, 1.2, 0.8, 0);

		GhostState st = GhostState.of(w.getServer());
		GhostData d = st.data(p.getUuid());
		if (inside && !d.powers && p.isAlive()) {
			d.pendingPowers = true;
			d.respawnDim = w.getRegistryKey().getValue().toString();
			d.respawnPos = BlockPos.ofFloored(front);
			st.markDirty();
			p.sendMessage(Text.literal("The Ghost Portal surges to life... with you inside it!").formatted(Formatting.GREEN), false);
			DamageSource src = new DamageSource(
					w.getRegistryManager().get(RegistryKeys.DAMAGE_TYPE).entryOf(PhantomMod.GHOST_PORTAL_DAMAGE));
			p.damage(src, Float.MAX_VALUE);
			if (p.isAlive()) finishGhostRebirth(p); // something saved them: give powers anyway
		} else {
			p.sendMessage(Text.literal("The Ghost Portal is open! Step inside to enter the Ghost Zone.").formatted(Formatting.GREEN), false);
		}
	}

	/** Called after the player respawns: put them in front of the portal and give them their powers. */
	public static void finishGhostRebirth(ServerPlayerEntity p) {
		GhostState st = GhostState.of(p.getServer());
		GhostData d = st.data(p.getUuid());
		if (!d.pendingPowers) return;
		if (d.respawnDim != null && d.respawnPos != null) {
			ServerWorld dest = p.getServer().getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(d.respawnDim)));
			if (dest != null) {
				p.teleport(dest, d.respawnPos.getX() + 0.5, d.respawnPos.getY(), d.respawnPos.getZ() + 0.5, p.getYaw(), p.getPitch());
			}
		}
		GhostPowers.grantPowers(p);
		p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("You're half ghost!").formatted(Formatting.GREEN, Formatting.BOLD)));
		p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("Press V to go ghost").formatted(Formatting.WHITE)));
		p.sendMessage(Text.literal("You came back... different. You have ghost powers!").formatted(Formatting.GREEN), false);
		p.sendMessage(Text.literal("V = go ghost / go human.  R = Ecto Blast.  G / H / B = new powers you unlock with stat points.").formatted(Formatting.GRAY), false);
		p.sendMessage(Text.literal("Stay in ghost form to earn stat points (1 every 30 seconds).").formatted(Formatting.GRAY), false);
		ServerWorld w = p.getServerWorld();
		w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_ALLAY_AMBIENT_WITHOUT_ITEM, SoundCategory.PLAYERS, 1.0f, 0.6f);
		w.spawnParticles(GhostPowers.GREEN, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 1.0, 0.5, 0);
	}

	private static Vec3d centerOf(Frame f) {
		double x = 0, y = 0, z = 0;
		for (BlockPos p : f.interior()) {
			x += p.getX();
			y += p.getY();
			z += p.getZ();
		}
		int n = f.interior().size();
		return new Vec3d(x / n + 0.5, y / n + 0.5, z / n + 0.5);
	}

	/** A safe spot 2 blocks in front of the bottom of the portal. */
	private static Vec3d frontOf(ServerWorld w, Frame f) {
		int minY = Integer.MAX_VALUE;
		for (BlockPos p : f.interior()) minY = Math.min(minY, p.getY());
		double sum = 0;
		int count = 0;
		BlockPos any = null;
		for (BlockPos p : f.interior()) {
			if (p.getY() == minY) {
				sum += f.axis() == Direction.Axis.X ? p.getX() : p.getZ();
				count++;
				any = p;
			}
		}
		double along = sum / count + 0.5;
		Direction normal = f.axis() == Direction.Axis.X ? Direction.SOUTH : Direction.EAST;
		for (Direction side : new Direction[]{normal, normal.getOpposite()}) {
			BlockPos spot = any.offset(side, 2);
			if (isStandable(w, spot)) return toVec(f.axis(), along, spot);
		}
		return toVec(f.axis(), along, any.offset(normal, 2));
	}

	private static Vec3d toVec(Direction.Axis axis, double along, BlockPos spot) {
		return axis == Direction.Axis.X
				? new Vec3d(along, spot.getY(), spot.getZ() + 0.5)
				: new Vec3d(spot.getX() + 0.5, spot.getY(), along);
	}

	private static boolean isStandable(ServerWorld w, BlockPos pos) {
		return w.getBlockState(pos).getCollisionShape(w, pos).isEmpty()
				&& w.getBlockState(pos.up()).getCollisionShape(w, pos.up()).isEmpty();
	}

	// ---------------------------------------------------------------- travel

	public static void requestTravel(ServerPlayerEntity p, BlockPos portalPos) {
		TRAVEL.putIfAbsent(p.getUuid(), portalPos.toImmutable());
	}

	private static void travel(ServerPlayerEntity p, BlockPos portalPos) {
		MinecraftServer server = p.getServer();
		int now = server.getTicks();
		Integer last = LAST_TRAVEL.get(p.getUuid());
		if (last != null && now - last < TRAVEL_COOLDOWN) return;
		ServerWorld from = p.getServerWorld();
		BlockState ps = from.getBlockState(portalPos);
		if (!ps.isOf(ModBlocks.GHOST_PORTAL)) return;
		LAST_TRAVEL.put(p.getUuid(), now);

		GhostState st = GhostState.of(server);
		GhostData d = st.data(p.getUuid());

		if (from.getRegistryKey() == GHOST_ZONE) {
			ServerWorld dest = null;
			BlockPos spot = d.portalPos;
			if (d.portalDim != null) {
				dest = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(d.portalDim)));
			}
			if (dest == null || spot == null) {
				dest = server.getOverworld();
				spot = dest.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, dest.getSpawnPos());
			}
			p.teleport(dest, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, p.getYaw(), p.getPitch());
			GhostPowers.bar(p, "You escaped the Ghost Zone!", Formatting.GREEN);
		} else {
			ServerWorld zone = server.getWorld(GHOST_ZONE);
			if (zone == null) {
				GhostPowers.bar(p, "The Ghost Zone couldn't be found in this world.", Formatting.RED);
				return;
			}
			// Remember where to come back to: 2 blocks out of the portal, on the side you walked in from
			Direction.Axis axis = ps.get(GhostPortalBlock.AXIS);
			BlockPos bottom = portalPos;
			while (from.getBlockState(bottom.down()).isOf(ModBlocks.GHOST_PORTAL)) bottom = bottom.down();
			Direction normal = axis == Direction.Axis.X ? Direction.SOUTH : Direction.EAST;
			Vec3d look = p.getRotationVec(1f);
			double facing = axis == Direction.Axis.X ? look.z : look.x;
			Direction cameFrom = facing > 0 ? normal.getOpposite() : normal;
			d.portalDim = from.getRegistryKey().getValue().toString();
			d.portalPos = bottom.offset(cameFrom, 2);
			st.markDirty();

			sendToGhostZone(p, zone);
		}
		ServerWorld now2 = p.getServerWorld();
		now2.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_PORTAL_TRAVEL, SoundCategory.PLAYERS, 0.4f, 1.6f);
	}

	public static void sendToGhostZone(ServerPlayerEntity p, ServerWorld zone) {
		Vec3d arrival = ghostZoneArrival(zone, p.getBlockPos());
		p.teleport(zone, arrival.x, arrival.y, arrival.z, 180f, 0f);
		LAST_TRAVEL.put(p.getUuid(), p.getServer().getTicks());
		p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("The Ghost Zone").formatted(Formatting.GREEN, Formatting.BOLD)));
		p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("Walk back through the portal to go home").formatted(Formatting.GRAY)));
	}

	/** Finds the return portal near these coordinates in the Ghost Zone, or builds one on a floating platform. */
	private static Vec3d ghostZoneArrival(ServerWorld zone, BlockPos near) {
		int bx = near.getX();
		int bz = near.getZ();
		int y0 = 100;
		BlockPos.Mutable m = new BlockPos.Mutable();
		for (int dx = -16; dx <= 16; dx++) {
			for (int dz = -16; dz <= 16; dz++) {
				m.set(bx + dx, y0 + 1, bz + dz);
				if (zone.getBlockState(m).isOf(ModBlocks.GHOST_PORTAL)
						&& !zone.getBlockState(m.west()).isOf(ModBlocks.GHOST_PORTAL)) {
					return new Vec3d(m.getX() + 1.0, y0, m.getZ() + 2.5);
				}
			}
		}

		int x0 = bx - 2;
		int z0 = bz;
		int flags = Block.NOTIFY_LISTENERS;
		BlockState air = Blocks.AIR.getDefaultState();
		for (int x = x0 - 3; x <= x0 + 6; x++) {
			for (int z = z0 - 3; z <= z0 + 5; z++) {
				for (int y = y0; y <= y0 + 6; y++) zone.setBlockState(m.set(x, y, z), air, flags);
				zone.setBlockState(m.set(x, y0 - 1, z), ModBlocks.ECTO_GRASS.getDefaultState(), flags);
				zone.setBlockState(m.set(x, y0 - 2, z), ModBlocks.ECTO_STONE.getDefaultState(), flags);
			}
		}
		BlockState iron = Blocks.IRON_BLOCK.getDefaultState();
		BlockState black = Blocks.BLACK_CONCRETE.getDefaultState();
		for (int i = 0; i <= 3; i++) {
			zone.setBlockState(m.set(x0 + i, y0, z0), (i == 0 || i == 3) ? iron : black, flags);
			zone.setBlockState(m.set(x0 + i, y0 + 4, z0), (i == 2) ? black : iron, flags);
		}
		for (int j = 1; j <= 3; j++) {
			zone.setBlockState(m.set(x0, y0 + j, z0), black, flags);
			zone.setBlockState(m.set(x0 + 3, y0 + j, z0), black, flags);
		}
		BlockState portal = ModBlocks.GHOST_PORTAL.getDefaultState().with(GhostPortalBlock.AXIS, Direction.Axis.X);
		for (int i = 1; i <= 2; i++) {
			for (int j = 1; j <= 3; j++) zone.setBlockState(m.set(x0 + i, y0 + j, z0), portal, flags);
		}
		return new Vec3d(x0 + 2.0, y0, z0 + 2.5);
	}
}
